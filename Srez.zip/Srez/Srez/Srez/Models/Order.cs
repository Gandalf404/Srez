﻿using System;
using System.Collections.Generic;

namespace Srez.Models;

public partial class Order
{
    public int OrderId { get; set; }

    public DateOnly OrderDate { get; set; }

    public int OrderSum { get; set; }

    public virtual User OrderNavigation { get; set; } = null!;

    public virtual ICollection<OrderService> OrderServices { get; set; } = new List<OrderService>();
}
