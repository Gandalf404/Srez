﻿using Srez.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Srez
{
    public class DB
    {
        public static SrezContext srezContext = new SrezContext();
    }
}
