﻿using Srez;
using Srez.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Srez.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }

        private void EnterButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                User user = DB.srezContext.Users.FirstOrDefault(c => c.UserLogin == LoginTextBox.Text && c.UserPassword == PasswordTextBox.Password);
                if (user != null)
                {
                    NavigationService.Navigate(new MainPage());
                }
                else
                {
                    throw new Exception("Неверный логин/пароль.");
                }
            }
            catch when (String.IsNullOrWhiteSpace(LoginTextBox.Text))
            {
                MessageBox.Show("Необходимо заполнить поле Логин.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch when (String.IsNullOrWhiteSpace(PasswordTextBox.Password))
            {
                MessageBox.Show("Необходимо заполнить поле Пароль.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
