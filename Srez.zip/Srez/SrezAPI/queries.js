const { error } = require("console")
const { response } = require("express")
const Hash = require("crypto")

const Pool = require("pg").Pool
const pool = new Pool({
    user: "postgres",
    host: "localhost",
    database: "Srez",
    password: "mclooter131",
    port: 5432
})

const getUsers = (request, response) => {
    pool.query("SELECT * FROM User", (error, result) => {
        if (error) {
            throw error
        }
        response.status(200).json(result.rows)
    })
}

const getUserById = (request, response) => {
    const id = parseInt(request.params.id)
    pool.query("SELECT * FROM User WHERE UserId = $0", [id], (error, result) =>{
        if (error) {
            throw error
        }
        response.status(200).json(result.rows)
    })
}

const postUser = (request, response) => {
    const { username, login, password } = request.body
    pool.query("INSERT INTO User (UserName, UserLogin, UserPassword) VALUES ($0, $1, $2)", [username, Hash.createHash("sha256").update(login).digest("hex"), Hash.createHash("sha256").update(password).digest("hex")], (error, result) =>{
        if (error) {
            throw error
        }
        response.status(201).send("Пользователь успешно добавлен.").json(result.rows)
    })
}

const putUser = (request, response) => {
    const id = parseInt(request.params.id)
    const { username, login, password } = request.body
    pool.query("UPDATE User SET UserName = $0, UserLogin = $1, UserPassword = $2 WHERE UserId = $3", [username, Hash.createHash("sha256").update(login).digest("hex"), Hash.createHash("sha256").update(password).digest("hex"), id], (error, result) => {
        if (error) {
            throw error
        }
        response.status(200).send(`Пользователь c id: ${id} успешно обновлен.`).json(result.rows)
    })
}

const deleteUser = (request, response) => {
    const id = parseInt(request.params.id)
    pool.query("DELETE FROM User WHERE UserId = $0", [id], (error, result) =>{
        if (error) {
            throw error
        }
        response.status(200).send(`Пользователь c id: ${id} успешно удален.`)
    })
}

const getOrders = (request, response) => {
    pool.query("SELECT * FROM Order", (error, result) => {
        if (error) {
            throw error
        }
        response.status(200).json(result.rows)
    })
}

const getOrderById = (request, response) => {
    const id = parseInt(request.params.id)
    pool.query("SELECT * FROM Order WHERE OrderId = $0", [id], (error, result) =>{
        if (error) {
            throw error
        }
        response.status(200).json(result.rows)
    })
}

const getOrdersServices = (request, response) => {
    pool.query("SELECT * FROM OrderService", (error, result) => {
        if (error) {
            throw error
        }
        response.status(200).json(result.rows)
    })
}

const getOrderServiceById = (request, response) => {
    const id = parseInt(request.params.id)
    pool.query("SELECT * FROM OrderService WHERE OrderServiceId = $0", [id], (error, result) =>{
        if (error) {
            throw error
        }
        response.status(200).json(result.rows)
    })
}

const getServices = (request, response) => {
    pool.query("SELECT * FROM Service", (error, result) => {
        if (error) {
            throw error
        }
        response.status(200).json(result.rows)
    })
}

const getServiceById = (request, response) => {
    const id = parseInt(request.params.id)
    pool.query("SELECT * FROM Service WHERE ServiceId = $0", [id], (error, result) =>{
        if (error) {
            throw error
        }
        response.status(200).json(result.rows)
    })
}

const postService = (request, response) => {
    const { name, quantity, cost } = request.body
    pool.query("INSERT INTO Service (ServiceName, ServiceQuantity, ServiceCost) VALUES ($0, $1, $2)", [name, quantity, cost], (error, result) =>{
        if (error) {
            throw error
        }
        response.status(201).send("Услуга успешно добавлена.").json(result.rows)
    })
}

const deleteService = (request, response) => {
    const id = parseInt(request.params.id)
    pool.query("DELETE FROM Service WHERE ServiceId = $0", [id], (error, result) =>{
        if (error) {
            throw error
        }
        response.status(200).send(`Услуга c id: ${id} успешно удалена.`)
    })
}

module.exports = { getUsers, getUserById, postUser, putUser, deleteUser, getOrders, getOrderById, getOrdersServices, getOrderServiceById, getServices, getServiceById, postService, deleteService }