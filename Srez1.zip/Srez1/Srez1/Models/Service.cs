﻿using System;
using System.Collections.Generic;

namespace Srez1.Models;

public partial class Service
{
    public int ServiceId { get; set; }

    public string ServiceName { get; set; } = null!;

    public int ServiceQuantiy { get; set; }

    public int? ServiceCost { get; set; }

    public virtual ICollection<OrderService> OrderServices { get; set; } = new List<OrderService>();
}
