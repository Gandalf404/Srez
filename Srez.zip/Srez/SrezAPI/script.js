const express = require("express")
const bodyParser = require("body-parser")
const db = require("./queries")

const app = express()
const port = 3000

app.use(bodyParser.json)
app.use(
    bodyParser.urlencoded({
        extended: true
    }),
)

app.listen(port, () =>{
    console.log("API на порту:", port)
})

app.get("/users", db.getUsers)
app.get("/users/:id", db.getUserById)
app.post("/users", db.postUser)
app.put("/users/:id", db.putUser)
app.delete("/users/:id", db.deleteUser)
app.get("/orders", db.getOrders)
app.get("/orders/:id", db.getOrderById)
app.get("/orders-services", db.getOrdersServices)
app.get("/orders-services/:id", db.getOrderServiceById)
app.get("/services", db.getServices)
app.get("/services/:id", db.getServiceById)
app.post("/service", db.postService)
app.delete("/service/:id", db.deleteService)